namespace Stripe.Models
{
    public class CompletedViewModel
    {
        public string Message { get; set; }
        public bool HasSubscriptions { get; set; }
    }
}